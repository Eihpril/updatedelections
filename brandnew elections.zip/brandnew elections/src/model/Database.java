package src.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Database {
    private Connection conn;

    // Constructor to establish the database connection
    public Database() {
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/brandnew_system", "root", "Mawira@10926");
            System.out.println("✅ Database connection established.");
        } catch (SQLException e) {
            System.out.println("❌ Failed to connect to the database.");
            e.printStackTrace();
        }
    }

    // Consolidated recordVote method
    public boolean recordVote(int voterId, int candidateId, int electionId) {
        System.out.println("DEBUG: Voter ID passed to recordVote: " + voterId);
        // Check if the voter exists
        if (!doesVoterExist(voterId)) {
            System.out.println("❌ Voter does not exist.");
            return false; // Prevent voting for a non-existent voter
        }

        // Check if the election exists
        if (!doesElectionExist(electionId)) {
            System.out.println("❌ Election does not exist.");
            return false; // Prevent voting in a non-existent election
        }

        // Check if the voter has already voted in this election
        if (hasVoterVoted(voterId, electionId)) {
            System.out.println("❌ Voter has already voted in this election.");
            return false; // Prevent duplicate voting
        }

        // Record the vote
        String voteQuery = "INSERT INTO votes (voter_id, candidate_id, election_id) VALUES (?, ?, ?)";
        String updateCandidateQuery = "UPDATE candidates SET vote_count = vote_count + 1 WHERE candidate_id = ?";
        try (PreparedStatement voteStmt = conn.prepareStatement(voteQuery);
             PreparedStatement updateStmt = conn.prepareStatement(updateCandidateQuery)) {
            // Insert into votes table
            voteStmt.setInt(1, voterId);
            voteStmt.setInt(2, candidateId);
            voteStmt.setInt(3, electionId);
            voteStmt.executeUpdate();

            // Update the candidate's vote count
            updateStmt.setInt(1, candidateId);
            updateStmt.executeUpdate();

            System.out.println("✅ Vote recorded successfully.");
            return true;
        } catch (SQLException e) {
            System.out.println("❌ Failed to record vote.");
            e.printStackTrace();
            return false;
        }
    }

    
    public boolean recordVote(int voterId, String candidateName, int electionId) {
        String query = "INSERT INTO votes (voter_id, candidate_id, election_id) " +
                       "SELECT ?, c.candidate_id, ? FROM candidates c WHERE c.candidate_name = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, voterId);
            stmt.setInt(2, electionId);
            stmt.setString(3, candidateName);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("❌ Failed to record vote.");
            e.printStackTrace();
            return false;
        }
    }

    public boolean recordVote(int voterId, String candidateName) {
        int electionId = 1; // Hard-coded election ID

        // Check if the voter has already voted in this election
        String checkQuery = "SELECT COUNT(*) FROM votes WHERE voter_id = ? AND election_id = ?";
        try (PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {
            checkStmt.setInt(1, voterId);
            checkStmt.setInt(2, electionId);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                System.out.println("❌ Voter has already voted in this election.");
                return false; // Prevent duplicate vote
            }
        } catch (SQLException e) {
            System.out.println("❌ Failed to check for duplicate vote.");
            e.printStackTrace();
            return false;
        }

        // Insert the vote
        String insertQuery = "INSERT INTO votes (voter_id, candidate_id, election_id) " +
                             "SELECT ?, c.candidate_id, ? FROM candidates c WHERE c.candidate_name = ?";
        try (PreparedStatement insertStmt = conn.prepareStatement(insertQuery)) {
            insertStmt.setInt(1, voterId);
            insertStmt.setInt(2, electionId);
            insertStmt.setString(3, candidateName);

            System.out.println("DEBUG: Voter ID: " + voterId + ", Candidate Name: " + candidateName + ", Election ID: " + electionId);

            return insertStmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("❌ Failed to record vote.");
            e.printStackTrace();
            return false;
        }
    }

    // Helper method to check if a voter exists
    private boolean doesVoterExist(int voterId) {
        String query = "SELECT voter_id FROM voters WHERE voter_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, voterId);
            ResultSet rs = stmt.executeQuery();
            return rs.next(); // Return true if a record is found
        } catch (SQLException e) {
            System.out.println("❌ Failed to validate voter ID.");
            e.printStackTrace();
            return false;
        }
    }

    // Helper method to check if an election exists
    public boolean doesElectionExist(int electionId) {
        String query = "SELECT * FROM elections WHERE election_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, electionId); // Set the election ID
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return true; // Election exists
            }
        } catch (SQLException e) {
            System.out.println("❌ Failed to check if election exists.");
            e.printStackTrace();
        }
        return false; // Election does not exist
    }

    // Helper method to check if a voter has already voted in an election
    public boolean hasVoterVoted(int voterId, int electionId) {
        String query = "SELECT * FROM votes WHERE voter_id = ? AND election_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, voterId); // Set the voter ID
            stmt.setInt(2, electionId); // Set the election ID
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("❌ Voter has already voted in this election.");
                return true; // Voter has already voted
            }
        } catch (SQLException e) {
            System.out.println("❌ Failed to check if voter has already voted.");
            e.printStackTrace();
        }
        return false; // Voter has not voted
    }

    public int authenticateVoterAndGetId(String username, String password) {
        String query = "SELECT voter_id FROM voters WHERE username = ? AND password = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int voterId = rs.getInt("voter_id");
                System.out.println("✅ Voter authenticated successfully. Voter ID: " + voterId);
                return voterId;
            } else {
                System.out.println("❌ Invalid username or password.");
                return -1;
            }
        } catch (SQLException e) {
            System.out.println("❌ Failed to authenticate voter.");
            e.printStackTrace();
            return -1;
        }
    }

    public boolean authenticateAdmin(String username, String password) {
        String query = "SELECT * FROM admins WHERE username = ? AND password = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, password);
    
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("✅ Admin authenticated successfully.");
                return true; // Admin found
            } else {
                System.out.println("❌ Invalid admin username or password.");
                return false; // Admin not found
            }
        } catch (SQLException e) {
            System.out.println("❌ Failed to authenticate admin.");
            e.printStackTrace();
            return false;
        }
    }
    public boolean verifyCitizenDetails(String nationalId, String firstName, String lastName) {
        String query = "SELECT * FROM citizens WHERE national_id = ? AND first_name = ? AND last_name = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, nationalId);
            stmt.setString(2, firstName);
            stmt.setString(3, lastName);
            ResultSet rs = stmt.executeQuery();
            return rs.next(); // Return true if a matching record is found
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    public boolean isCitizenAlreadyRegistered(String nationalId) {
        String query = "SELECT is_registered FROM citizens WHERE national_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, nationalId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getBoolean("is_registered"); // Return true if already registered
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    public Object[][] getElectionResults() {
        String query = "SELECT candidate_name, party, vote_count FROM candidates ORDER BY vote_count DESC";
    
        try (PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
    
            List<Object[]> results = new ArrayList<>();
            while (rs.next()) {
                results.add(new Object[]{
                    rs.getString("candidate_name"), // Replace with the correct column name
                    rs.getString("party"),     // Replace with the correct column name
                    rs.getInt("vote_count")
                });
            }
    
            return results.toArray(new Object[0][]);
        } catch (SQLException e) {
            System.out.println("❌ Failed to fetch election results.");
            e.printStackTrace();
            return new Object[0][];
        }
    }
    // Method to authenticate a voter
    public boolean authenticateVoter(String username, String password) {
        String query = "SELECT * FROM voters WHERE username = ? AND password = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, password);

            // Execute the query
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("✅ Voter authenticated successfully.");
                return true; // Voter found
            } else {
                System.out.println("❌ Invalid username or password.");
                return false; // Voter not found
            }
        } catch (SQLException e) {
            System.out.println("❌ Failed to authenticate voter.");
            e.printStackTrace();
            return false;
        }
    }

    // Method to register a voter
    public boolean registerVoter(String nationalId, String username, String password) {
        String insertVoterQuery = "INSERT INTO voters (national_id, username, password) VALUES (?, ?, ?)";
        String updateCitizenQuery = "UPDATE citizens SET is_registered = TRUE WHERE national_id = ?";
        try (PreparedStatement insertStmt = conn.prepareStatement(insertVoterQuery);
             PreparedStatement updateStmt = conn.prepareStatement(updateCitizenQuery)) {
    
            // Insert into voters table
            insertStmt.setString(1, nationalId);
            insertStmt.setString(2, username);
            insertStmt.setString(3, password);
            int rowsInserted = insertStmt.executeUpdate();
    
            // Update citizens table
            updateStmt.setString(1, nationalId);
            int rowsUpdated = updateStmt.executeUpdate();
    
            return rowsInserted > 0 && rowsUpdated > 0; // Return true if both operations succeed
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    // Method to fetch all candidates
    // Corrected getAllCandidates method
public List<Candidate> getAllCandidates() {
    String query = "SELECT * FROM candidates";
    List<Candidate> candidates = new ArrayList<>();
    try (PreparedStatement stmt = conn.prepareStatement(query)) {
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            Candidate candidate = new Candidate(
                rs.getInt("candidate_id"),
                rs.getInt("election_id"),
                rs.getString("candidate_name"),
                rs.getString("party"),
                rs.getInt("vote_count"),
                rs.getInt("age"),
                rs.getString("id_number"),
                rs.getString("phone_number"),
                rs.getString("email"),
                rs.getString("position"),
                rs.getString("county")
            );
            candidates.add(candidate);
        }
    } catch (SQLException e) {
        System.out.println("❌ Failed to fetch candidates from the database.");
        e.printStackTrace();
    }
    return candidates;
}

    // Method to fetch all candidates for voting
    public List<Object[]> getAllCandidatesForVoting() {
        String query = "SELECT candidate_id, candidate_name, party, position, county FROM candidates";
        List<Object[]> candidates = new ArrayList<>();
        try (PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                candidates.add(new Object[]{
                    rs.getInt("candidate_id"),
                    rs.getString("candidate_name"),
                    rs.getString("party"),
                    rs.getString("position"),
                    rs.getString("county")
                });
                System.out.println("DEBUG: Fetched candidate: " + candidates.get(candidates.size() - 1));
            }
        } catch (SQLException e) {
            System.out.println("❌ Failed to fetch candidates for voting.");
            e.printStackTrace();
        }
        return candidates;
    }
    // Removed duplicate recordVote method to resolve the issue
    // Method to check if a voter has already voted
    public boolean hasVoterVoted(int voterId) {
        String query = "SELECT * FROM votes WHERE voter_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, voterId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("❌ Voter has already voted.");
                return true; // Voter has already voted
            }
        } catch (SQLException e) {
            System.out.println("❌ Failed to check if voter has already voted.");
            e.printStackTrace();
        }
        return false; // Voter has not voted
    }
    public int getLoggedInVoterId(String username) {
        String query = "SELECT voter_id FROM voters WHERE username = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("voter_id");
            }
        } catch (SQLException e) {
            System.out.println("❌ Failed to fetch voter ID.");
            e.printStackTrace();
        }
        return -1; // Return -1 if voter ID is not found
    }

    // Removed duplicate getElectionResults() method to resolve the issue
    // Removed duplicate getElectionResults() method to resolve the issue
    // Method to retrieve all votes
    public List<Vote> getAllVotes() {
        String query = "SELECT * FROM votes";
        List<Vote> votes = new ArrayList<>();
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Vote vote = new Vote(
                    rs.getInt("vote_id"),
                    rs.getInt("voter_id"),
                    rs.getInt("candidate_id")
                );
                votes.add(vote);
            }
        } catch (SQLException e) {
            System.out.println("❌ Failed to retrieve votes.");
            e.printStackTrace();
        }
        return votes;
    }

    // Method to update a candidate
    public boolean updateCandidate(Candidate candidate) {
        String query = "UPDATE candidates SET candidate_name = ?, party = ?, age = ?, id_number = ?, phone_number = ?, email = ?, position = ?, county = ? WHERE candidate_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, candidate.getCandidateName());
            stmt.setString(2, candidate.getParty());
            stmt.setInt(3, candidate.getAge());
            stmt.setString(4, candidate.getIdNumber());
            stmt.setString(5, candidate.getPhoneNumber());
            stmt.setString(6, candidate.getEmail());
            stmt.setString(7, candidate.getPosition());
            stmt.setString(8, candidate.getCounty());
            stmt.setInt(9, candidate.getCandidateId());

            // Execute the query
            stmt.executeUpdate();
            System.out.println("✅ Candidate updated successfully in the database.");
            return true;
        } catch (SQLException e) {
            System.out.println("❌ Failed to update candidate in the database.");
            e.printStackTrace();
            return false;
        }
    }

    // Method to delete a candidate
    public boolean deleteCandidate(int candidateId) {
        String query = "DELETE FROM candidates WHERE candidate_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, candidateId);

            // Execute the query
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("✅ Candidate deleted successfully from the database.");
                return true;
            } else {
                System.out.println("❌ No candidate found with the given ID.");
                return false;
            }
        } catch (SQLException e) {
            System.out.println("❌ Failed to delete candidate from the database.");
            e.printStackTrace();
            return false;
        }
    }
    public boolean createElection(String name, Date startDate, Date endDate) {
        String query = "INSERT INTO elections (election_name, start_date, end_date, is_active) VALUES (?, ?, ?, 0)";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setDate(2, startDate);
            stmt.setDate(3, endDate);
            return stmt.executeUpdate() > 0; // Return true if the election is created successfully
        } catch (SQLException e) {
            System.out.println("❌ Failed to create election.");
            e.printStackTrace();
            return false;
        }
    }
    public boolean updateElection(int electionId, String newName, Date newStartDate, Date newEndDate) {
        String query = "UPDATE elections SET election_name = ?, start_date = ?, end_date = ? WHERE election_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, newName);
            stmt.setDate(2, newStartDate);
            stmt.setDate(3, newEndDate);
            stmt.setInt(4, electionId);
            return stmt.executeUpdate() > 0; // Return true if the election is updated successfully
        } catch (SQLException e) {
            System.out.println("❌ Failed to update election.");
            e.printStackTrace();
            return false;
        }
    }
    public boolean deleteElection(int electionId) {
        String checkQuery = "SELECT is_active FROM elections WHERE election_id = ?";
        String deleteQuery = "UPDATE elections SET deleted = 1 WHERE election_id = ?";
        try (PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {
            checkStmt.setInt(1, electionId);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next() && rs.getBoolean("is_active")) {
                System.out.println("❌ Cannot delete an active election.");
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }

        try (PreparedStatement deleteStmt = conn.prepareStatement(deleteQuery)) {
            deleteStmt.setInt(1, electionId);
            return deleteStmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("❌ Failed to delete election.");
            e.printStackTrace();
            return false;
        }
    }
    public boolean setElectionActiveStatus(int electionId, boolean isActive) {
        String query = "UPDATE elections SET is_active = ? WHERE election_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setBoolean(1, isActive);
            stmt.setInt(2, electionId);
            return stmt.executeUpdate() > 0; // Return true if the status is updated successfully
        } catch (SQLException e) {
            System.out.println("❌ Failed to update election active status.");
            e.printStackTrace();
            return false;
        }
    }
    public Object[] getActiveElection() {
        String query = "SELECT election_id, election_name, start_date, end_date FROM elections WHERE is_active = 1 LIMIT 1";
        try (PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return new Object[]{
                    rs.getInt("election_id"),
                    rs.getString("election_name"),
                    rs.getDate("start_date"),
                    rs.getDate("end_date")
                };
            }
        } catch (SQLException e) {
            System.out.println("❌ Failed to fetch active election.");
            e.printStackTrace();
        }
        return null; // Return null if no active election is found
    }
    public List<Object[]> getActiveElections() {
        String query = "SELECT election_id, election_name, start_date, end_date, is_active FROM elections WHERE deleted = 0";
        List<Object[]> elections = new ArrayList<>();
        try (PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                elections.add(new Object[]{
                    rs.getInt("election_id"),
                    rs.getString("election_name"),
                    rs.getDate("start_date"),
                    rs.getDate("end_date"),
                    rs.getBoolean("is_active")
                });
            }
        } catch (SQLException e) {
            System.out.println("❌ Failed to fetch active elections.");
            e.printStackTrace();
        }
        return elections;
    }
    public List<Object[]> getElectionsForCandidateRegistration() {
        String query = "SELECT election_id, election_name FROM elections WHERE deleted = 0 AND is_active = 1";
        List<Object[]> elections = new ArrayList<>();
        try (PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                elections.add(new Object[]{rs.getInt("election_id"), rs.getString("election_name")});
            }
        } catch (SQLException e) {
            System.out.println("❌ Failed to fetch elections for candidate registration.");
            e.printStackTrace();
        }
        return elections;
    }
    public int getActiveElectionId() {
        String query = "SELECT election_id FROM elections WHERE status = 'active' LIMIT 1";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("election_id"); // Return the active election ID
            }
        } catch (SQLException e) {
            System.out.println("❌ Failed to fetch active election ID.");
            e.printStackTrace();
        }
        return -1; // Return -1 if no active election is found
    }

    // Method to close the database connection
    public void closeConnection() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
                System.out.println("✅ Database connection closed.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public boolean authenticateUser(String username, String password, String role) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'authenticateUser'");
    }
    public boolean addCandidate(Candidate candidate) {
        String query = "INSERT INTO candidates (candidate_name, party, age, id_number, phone_number, email, position, county, election_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, candidate.getCandidateName());
            stmt.setString(2, candidate.getParty());
            stmt.setInt(3, candidate.getAge());
            stmt.setString(4, candidate.getIdNumber());
            stmt.setString(5, candidate.getPhoneNumber());
            stmt.setString(6, candidate.getEmail());
            stmt.setString(7, candidate.getPosition());
            stmt.setString(8, candidate.getCounty());
            stmt.setInt(9, candidate.getElectionId());
            return stmt.executeUpdate() > 0; // Return true if the candidate is added successfully
        } catch (SQLException e) {
            System.out.println("❌ Failed to add candidate.");
            e.printStackTrace();
            return false;
        }
    }
    public Connection getConnection() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getConnection'");
    }
    public String getAllElections() {
        String query = "SELECT election_id, election_name, start_date, end_date, is_active FROM elections";
        StringBuilder elections = new StringBuilder();
        try (PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                elections.append("ID: ").append(rs.getInt("election_id"))
                         .append(", Name: ").append(rs.getString("election_name"))
                         .append(", Start Date: ").append(rs.getDate("start_date"))
                         .append(", End Date: ").append(rs.getDate("end_date"))
                         .append(", Active: ").append(rs.getBoolean("is_active") ? "Yes" : "No")
                         .append("\n");
            }
        } catch (SQLException e) {
            System.out.println("❌ Failed to fetch elections.");
            e.printStackTrace();
        }
        return elections.toString();
    }
    public boolean addCandidate(String candidateName, int electionId) {
        String query = "INSERT INTO candidates (candidate_name, election_id) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, candidateName);
            stmt.setInt(2, electionId);
            return stmt.executeUpdate() > 0; // Return true if the candidate is added successfully
        } catch (SQLException e) {
            System.out.println("❌ Failed to add candidate.");
            e.printStackTrace();
            return false;
        }
    }

    public int authenticateVoterByNationalId(String nationalId, String username, String password) {
        String query = "SELECT voter_id FROM voters WHERE national_id = ? AND username = ? AND password = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, nationalId);
            stmt.setString(2, username);
            stmt.setString(3, password);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int voterId = rs.getInt("voter_id");
                System.out.println("✅ Voter authenticated successfully. Voter ID: " + voterId);
                return voterId;
            } else {
                System.out.println("❌ Invalid national ID, username, or password.");
                return -1;
            }
        } catch (SQLException e) {
            System.out.println("❌ Failed to authenticate voter.");
            e.printStackTrace();
            return -1;
        }
    }
}