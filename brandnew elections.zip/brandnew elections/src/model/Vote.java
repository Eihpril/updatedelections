package src.model;

public class Vote {
    private int voteId;       // Unique ID for the vote
    private int voterId;      // ID of the voter who cast the vote
    private int candidateId;  // ID of the candidate who received the vote
    private int electionId;   // ID of the election in which the vote was cast

    // Constructor with all fields
    public Vote(int voteId, int voterId, int candidateId, int electionId) {
        this.voteId = voteId;
        this.voterId = voterId;
        this.candidateId = candidateId;
        this.electionId = electionId;
    }

    // Overloaded constructor without voteId (for new votes)
    public Vote(int voterId, int candidateId, int electionId) {
        this.voterId = voterId;
        this.candidateId = candidateId;
        this.electionId = electionId;
    }

    // Getters and Setters
    public int getVoteId() {
        return voteId;
    }

    public void setVoteId(int voteId) {
        this.voteId = voteId;
    }

    public int getVoterId() {
        return voterId;
    }

    public void setVoterId(int voterId) {
        this.voterId = voterId;
    }

    public int getCandidateId() {
        return candidateId;
    }

    public void setCandidateId(int candidateId) {
        this.candidateId = candidateId;
    }

    public int getElectionId() {
        return electionId;
    }

    public void setElectionId(int electionId) {
        this.electionId = electionId;
    }

    // toString method for debugging
    @Override
    public String toString() {
        return "Vote{" +
                "voteId=" + voteId +
                ", voterId=" + voterId +
                ", candidateId=" + candidateId +
                ", electionId=" + electionId +
                '}';
    }
}