package src.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Voter {
    private Connection conn;

    // Voter fields
    private String fullName;
    private String nationalId;
    private String phoneNumber;
    private String email;
    private String username;
    private String password;

    // Constructor for database connection
    public Voter(Connection conn) {
        this.conn = conn;
    }

    // Getters and Setters
    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getNationalId() {
        return nationalId;
    }

    public void setNationalId(String nationalId) {
        this.nationalId = nationalId;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // Method to register a voter
    public boolean registerVoter(String nationalId, String username, String password) {
        String query = "INSERT INTO voters (national_id, username, password) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, nationalId);
            stmt.setString(2, username);
            stmt.setString(3, password);
            return stmt.executeUpdate() > 0; // Return true if the insertion was successful
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Method to mark a citizen as registered in the citizens table
    public boolean markCitizenAsRegistered(String nationalId) {
        String query = "UPDATE citizens SET is_registered = TRUE WHERE national_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, nationalId);
            return stmt.executeUpdate() > 0; // Return true if the update was successful
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Method to check if a voter has already voted
    public boolean hasVoted(int voterId) {
        String query = "SELECT has_voted FROM voters WHERE voter_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, voterId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getBoolean("has_voted");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Method to mark a voter as having voted
    public boolean markAsVoted(int voterId) {
        String query = "UPDATE voters SET has_voted = TRUE WHERE voter_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, voterId);
            return stmt.executeUpdate() > 0; // Return true if the update was successful
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}