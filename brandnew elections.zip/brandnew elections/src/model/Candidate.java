package src.model;

public class Candidate {
    private int candidateId;
    private int electionId;
    private String candidateName;
    private String party;
    private int voteCount;
    private int age;
    private String idNumber;
    private String phoneNumber;
    private String email;
    private String position;
    private String county;

    // Constructor
    public Candidate(int candidateId, int electionId, String candidateName, String party, int voteCount, int age, String idNumber, String phoneNumber, String email, String position, String county) {
        this.candidateId = candidateId;
        this.electionId = electionId;
        this.candidateName = candidateName;
        this.party = party;
        this.voteCount = voteCount;
        this.age = age;
        this.idNumber = idNumber;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.position = position;
        this.county = county;
    }

    // Overloaded constructor for creating a candidate without an ID (e.g., during addition)
    public Candidate(int electionId, String candidateName, String party, int age, String idNumber, String phoneNumber, String email, String position, String county) {
        this.electionId = electionId;
        this.candidateName = candidateName;
        this.party = party;
        this.age = age;
        this.idNumber = idNumber;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.position = position;
        this.county = county;
        this.voteCount = 0; // Default vote count is 0
    }

    // Getters and Setters
    public int getCandidateId() {
        return candidateId;
    }

    public void setCandidateId(int candidateId) {
        this.candidateId = candidateId;
    }

    public int getElectionId() {
        return electionId;
    }

    public void setElectionId(int electionId) {
        this.electionId = electionId;
    }

    public String getCandidateName() {
        return candidateName;
    }

    public void setCandidateName(String candidateName) {
        this.candidateName = candidateName;
    }

    public String getParty() {
        return party;
    }

    public void setParty(String party) {
        this.party = party;
    }

    public int getVoteCount() {
        return voteCount;
    }

    public void setVoteCount(int voteCount) {
        this.voteCount = voteCount;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    // Method to display candidate details (useful for debugging or logging)
    @Override
    public String toString() {
        return "Candidate{" +
                "candidateId=" + candidateId +
                ", electionId=" + electionId +
                ", candidateName='" + candidateName + '\'' +
                ", party='" + party + '\'' +
                ", voteCount=" + voteCount +
                ", age=" + age +
                ", idNumber='" + idNumber + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", email='" + email + '\'' +
                ", position='" + position + '\'' +
                ", county='" + county + '\'' +
                '}';
    }
}