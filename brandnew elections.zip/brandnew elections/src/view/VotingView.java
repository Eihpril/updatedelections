package src.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;

public class VotingView extends JFrame {
    private JTable candidatesTable;
    private DefaultTableModel tableModel;
    private JButton voteButton;
    private JButton viewResultsButton;

    public VotingView(List<Object[]> candidates) {
        setTitle("Voting Page");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window
        setLayout(new BorderLayout());

        // Table for candidates
        String[] columnNames = {"Name", "Party", "Age", "Position"};
        Object[][] tableData = new Object[candidates.size()][4];
        for (int i = 0; i < candidates.size(); i++) {
            tableData[i][0] = candidates.get(i)[1]; // Name
            tableData[i][1] = candidates.get(i)[2]; // Party
            tableData[i][2] = candidates.get(i)[3]; // Age
            tableData[i][3] = candidates.get(i)[4]; // Position
        }

        tableModel = new DefaultTableModel(tableData, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table cells non-editable
            }
        };
        candidatesTable = new JTable(tableModel);
        candidatesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); // Allow single row selection
        JScrollPane scrollPane = new JScrollPane(candidatesTable);
        add(scrollPane, BorderLayout.CENTER);

        // Buttons panel
        JPanel buttonPanel = new JPanel();
        voteButton = new JButton("Vote");
        voteButton.setFont(new Font("Arial", Font.BOLD, 14));
        voteButton.setBackground(new Color(34, 139, 34));
        voteButton.setForeground(Color.WHITE);
        voteButton.setFocusPainted(false);
        voteButton.setPreferredSize(new Dimension(100, 40));
        viewResultsButton = new JButton("View Results");
        viewResultsButton.setFont(new Font("Arial", Font.BOLD, 14));
        viewResultsButton.setBackground(new Color(70, 130, 180));
        viewResultsButton.setForeground(Color.WHITE);
        viewResultsButton.setFocusPainted(false);
        viewResultsButton.setPreferredSize(new Dimension(150, 40));
        buttonPanel.add(voteButton);
        buttonPanel.add(viewResultsButton);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public String getSelectedCandidate() {
        int selectedRow = candidatesTable.getSelectedRow();
        if (selectedRow != -1) {
            return (String) candidatesTable.getValueAt(selectedRow, 0); // Return the candidate's name
        }
        return null; // No row selected
    }

    public void addVoteButtonListener(ActionListener listener) {
        voteButton.addActionListener(listener);
    }

    public void addViewResultsButtonListener(ActionListener listener) {
        viewResultsButton.addActionListener(listener);
    }

    // Show a message dialog
    public void showMessage(String message, String title, int messageType) {
        JOptionPane.showMessageDialog(this, message, title, messageType);
    }
}