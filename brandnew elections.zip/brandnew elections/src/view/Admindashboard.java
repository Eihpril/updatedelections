package src.view;

import src.view.ManageCandidatesView;
import src.controller.ElectionManagementController;
import src.model.Database;
import src.view.ElectionManagementView;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Admindashboard extends JFrame {
    private JLabel electionStatusLabel; // Label to display the election status

    public Admindashboard() {
        setTitle("Admin Dashboard");
        setSize(600, 400); // Set the size of the window
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window
        setLayout(new GridBagLayout()); // Use GridBagLayout for precise alignment

        // Initialize the database connection
        Database database = new Database();

        // Create the election status label
        electionStatusLabel = new JLabel();
        electionStatusLabel.setFont(new Font("Arial", Font.BOLD, 14));
        electionStatusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        updateElectionStatus(database); // Fetch and display the current election status

        // Create buttons for admin actions
        JButton manageCandidatesButton = new JButton("Manage Candidates");
        JButton manageElectionsButton = new JButton("Manage Elections");
        JButton viewResultsButton = new JButton("View Results");

        // Set preferred size for buttons
        Dimension buttonSize = new Dimension(200, 40);
        manageCandidatesButton.setPreferredSize(buttonSize);
        manageElectionsButton.setPreferredSize(buttonSize);
        viewResultsButton.setPreferredSize(buttonSize);

        // Add action listeners for buttons
        manageCandidatesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ManageCandidatesView(); // Open Manage Candidates View
            }
        });

        manageElectionsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ElectionManagementView electionManagementView = new ElectionManagementView();
                new ElectionManagementController(electionManagementView, database); // Connect the view to the controller
                updateElectionStatus(database); // Refresh the election status after managing elections
            }
        });

        viewResultsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(Admindashboard.this, "View Results clicked!");
                // Add logic to open View Results View
            }
        });

        // Use GridBagConstraints to arrange components
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 0, 10, 0); // Add vertical spacing between components
        gbc.gridx = 0; // Center horizontally

        // Add the election status label
        gbc.gridy = 0;
        add(electionStatusLabel, gbc);

        // Add the buttons
        gbc.gridy = 1;
        add(manageCandidatesButton, gbc);

        gbc.gridy = 2;
        add(manageElectionsButton, gbc);

        gbc.gridy = 3;
        add(viewResultsButton, gbc);

        setVisible(true);
    }

    // Method to update the election status label
    private void updateElectionStatus(Database database) {
        Object[] activeElection = database.getActiveElection(); // Fetch the active election
        if (activeElection != null) {
            String electionName = (String) activeElection[1];
            electionStatusLabel.setText("Active Election: " + electionName);
            electionStatusLabel.setForeground(new Color(0, 128, 0)); // Green for active
        } else {
            electionStatusLabel.setText("No Active Election");
            electionStatusLabel.setForeground(Color.RED); // Red for no active election
        }
    }

    public static void main(String[] args) {
        new Admindashboard(); // Test the Admin Dashboard
    }
}