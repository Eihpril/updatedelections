package src.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class LoginView extends JFrame {
    private JTextField nationalIdField;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> roleDropdown;
    private JButton loginButton;
    private JButton registerButton;
    private JButton viewResultsButton;

    /**
     * Constructor for LoginView.
     * Initializes the login page UI components with a modern design.
     */
    public LoginView() {
        setTitle("Login Page");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window
        setLayout(new BorderLayout());

        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(34, 139, 34)); // Green background
        JLabel titleLabel = new JLabel("YOUR VOTE=YOUR FUTURE");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Main form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;

        // Role dropdown
        JLabel roleLabel = new JLabel("Select Role:");
        roleLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(roleLabel, gbc);

        gbc.gridx = 1;
        roleDropdown = new JComboBox<>(new String[]{"Voter", "Admin"});
        roleDropdown.setPreferredSize(new Dimension(200, 25));
        formPanel.add(roleDropdown, gbc);

        // National ID field
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel nationalIdLabel = new JLabel("National ID:");
        nationalIdLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(nationalIdLabel, gbc);

        gbc.gridx = 1;
        nationalIdField = new JTextField(15);
        formPanel.add(nationalIdField, gbc);

        // Username field
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(usernameLabel, gbc);

        gbc.gridx = 1;
        usernameField = new JTextField(15);
        formPanel.add(usernameField, gbc);

        // Password field
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(passwordLabel, gbc);

        gbc.gridx = 1;
        passwordField = new JPasswordField(15);
        formPanel.add(passwordField, gbc);

        // Buttons panel
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1, 3, 10, 0));

        loginButton = new JButton("Login");
        loginButton.setBackground(new Color(34, 139, 34));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        buttonPanel.add(loginButton);

        registerButton = new JButton("Register");
        registerButton.setBackground(new Color(70, 130, 180));
        registerButton.setForeground(Color.WHITE);
        registerButton.setFocusPainted(false);
        buttonPanel.add(registerButton);

        viewResultsButton = new JButton("View Results");
        viewResultsButton.setBackground(new Color(255, 165, 0));
        viewResultsButton.setForeground(Color.WHITE);
        viewResultsButton.setFocusPainted(false);
        buttonPanel.add(viewResultsButton);

        formPanel.add(buttonPanel, gbc);

        add(formPanel, BorderLayout.CENTER);

        // Footer panel
        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(new Color(240, 240, 240));
        JLabel footerLabel = new JLabel("© 2025 MonAmins election System. All rights reserved.");
        footerLabel.setFont(new Font("Arial", Font.ITALIC, 12));
        footerPanel.add(footerLabel);
        add(footerPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    /**
     * Gets the selected role from the dropdown.
     *
     * @return The selected role as a String.
     */
    public String getSelectedRole() {
        return (String) roleDropdown.getSelectedItem();
    }

    /**
     * Gets the entered National ID.
     *
     * @return The National ID as a String.
     */
    public String getNationalId() {
        return nationalIdField.getText();
    }

    /**
     * Gets the entered username.
     *
     * @return The username as a String.
     */
    public String getUsername() {
        return usernameField.getText();
    }

    /**
     * Gets the entered password.
     *
     * @return The password as a String.
     */
    public String getPassword() {
        return new String(passwordField.getPassword());
    }

    /**
     * Adds an ActionListener to the login button.
     *
     * @param listener The ActionListener to add.
     */
    public void addLoginButtonListener(ActionListener listener) {
        loginButton.addActionListener(listener);
    }

    /**
     * Adds an ActionListener to the register button.
     *
     * @param listener The ActionListener to add.
     */
    public void addRegisterButtonListener(ActionListener listener) {
        registerButton.addActionListener(listener);
    }

    /**
     * Adds an ActionListener to the view results button.
     *
     * @param listener The ActionListener to add.
     */
    public void addViewResultsButtonListener(ActionListener listener) {
        viewResultsButton.addActionListener(listener);
    }

    /**
     * Displays a message.
     *
     * @param message The message to display.
     */
    public void showMessage(String message) {
        System.out.println(message); // Display the message to the console or implement GUI logic
    }

    public String getVoterId() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getVoterId'");
    }
}