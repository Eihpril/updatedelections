package src.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class RegisterView extends JFrame {
    private JTextField nationalIdField, firstNameField, lastNameField, usernameField;
    private JPasswordField passwordField;
    private JButton submitButton; // Renamed for clarity

    public RegisterView() {
        setTitle("Voter Registration");
        setSize(500, 500); // Adjusted size for better layout
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        // Instructional message
        JLabel instructionLabel = new JLabel("Enter your details as they appear on your National ID.");
        instructionLabel.setFont(new Font("Arial", Font.BOLD, 14));
        instructionLabel.setForeground(Color.BLUE);

        // National ID field
        JLabel nationalIdLabel = new JLabel("National ID:");
        nationalIdField = new JTextField();
        nationalIdField.setPreferredSize(new Dimension(250, 30));

        // First name field
        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameField = new JTextField();
        firstNameField.setPreferredSize(new Dimension(250, 30));

        // Last name field
        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameField = new JTextField();
        lastNameField.setPreferredSize(new Dimension(250, 30));

        // Username field
        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField();
        usernameField.setPreferredSize(new Dimension(250, 30));

        // Password field
        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField();
        passwordField.setPreferredSize(new Dimension(250, 30));

        // Submit button
        submitButton = new JButton("Submit"); // Changed text from "Register" to "Submit"
        submitButton.setPreferredSize(new Dimension(250, 40));

        // Add components to the layout
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(instructionLabel, gbc); // Add the instructional message
        gbc.gridwidth = 1; // Reset grid width
        gbc.gridx = 0; gbc.gridy = 1;
        add(nationalIdLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 1;
        add(nationalIdField, gbc);
        gbc.gridx = 0; gbc.gridy = 2;
        add(firstNameLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 2;
        add(firstNameField, gbc);
        gbc.gridx = 0; gbc.gridy = 3;
        add(lastNameLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 3;
        add(lastNameField, gbc);
        gbc.gridx = 0; gbc.gridy = 4;
        add(usernameLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 4;
        add(usernameField, gbc);
        gbc.gridx = 0; gbc.gridy = 5;
        add(passwordLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 5;
        add(passwordField, gbc);
        gbc.gridx = 0; gbc.gridy = 6; gbc.gridwidth = 2;
        add(submitButton, gbc);

        setVisible(true);
    }

    // Getters for input fields
    public String getNationalId() {
        return nationalIdField.getText().trim();
    }

    public String getFirstName() {
        return firstNameField.getText().trim();
    }

    public String getLastName() {
        return lastNameField.getText().trim();
    }

    public String getUsername() {
        return usernameField.getText().trim();
    }

    public String getPassword() {
        return new String(passwordField.getPassword()).trim();
    }

    // Add a listener for the submit button with debug statements
    public void addSubmitButtonListener(ActionListener listener) {
        submitButton.addActionListener(e -> {
            System.out.println("DEBUG: Submit button clicked!");
            System.out.println("DEBUG: National ID entered: " + getNationalId());
            System.out.println("DEBUG: First Name entered: " + getFirstName());
            System.out.println("DEBUG: Last Name entered: " + getLastName());
            System.out.println("DEBUG: Username entered: " + getUsername());
            System.out.println("DEBUG: Password entered: " + getPassword());
            listener.actionPerformed(e);
        });
    }

    // Show a message dialog
    public void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "Message", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RegisterView()); // Test UI
    }
}