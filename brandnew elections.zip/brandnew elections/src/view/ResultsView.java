package src.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;

public class ResultsView extends JFrame {
    private JTable resultsTable;
    private DefaultTableModel tableModel;
    private JButton refreshButton;

    public ResultsView(Object[][] results) {
        setTitle("Election Results");
        setSize(600, 400); // Set the frame size
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null); // Center the frame on the screen

        // Main panel with GridBagLayout for centering components
        JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Add padding between components
        gbc.fill = GridBagConstraints.BOTH; // Allow components to resize

        // Table setup
        String[] columns = {"Candidate Name", "Party", "Vote Count"};
        tableModel = new DefaultTableModel(columns, 0); // Empty table initially
        resultsTable = new JTable(tableModel);
        resultsTable.setFillsViewportHeight(true);
        JScrollPane scrollPane = new JScrollPane(resultsTable);
        scrollPane.setPreferredSize(new Dimension(400, 200)); // Set table size

        // Add the table to the main panel
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        mainPanel.add(scrollPane, gbc);

        // Refresh button
        refreshButton = new JButton("Refresh");
        refreshButton.setFont(new Font("Arial", Font.BOLD, 14));
        refreshButton.setBackground(new Color(70, 130, 180));
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFocusPainted(false);
        refreshButton.setPreferredSize(new Dimension(150, 40));

        // Add the refresh button to the main panel
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        mainPanel.add(refreshButton, gbc);

        // Add the main panel to the frame
        add(mainPanel);

        // Populate the table with results
        setResults(results);

        setVisible(true);
    }

    // Method to populate the table with results
    public void setResults(Object[][] results) {
        tableModel.setRowCount(0); // Clear existing rows
        for (Object[] row : results) {
            tableModel.addRow(row);
        }
    }

    // Add a listener for the refresh button
    public void addRefreshButtonListener(ActionListener listener) {
        refreshButton.addActionListener(listener);
    }
}