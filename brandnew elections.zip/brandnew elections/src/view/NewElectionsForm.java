package src.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class NewElectionsForm extends JFrame {
    private JTextField electionNameField;
    private JTextField startDateField;
    private JTextField endDateField;
    private JButton submitButton;
    private JButton cancelButton;

    public NewElectionsForm() {
        setTitle("Create New Election");
        setSize(400, 300); // Compact size
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout()); // Use GridBagLayout for alignment

        // Create components
        JLabel electionNameLabel = new JLabel("Election Name:");
        electionNameField = new JTextField(20);

        JLabel startDateLabel = new JLabel("Start Date (yyyy-MM-dd):");
        startDateField = new JTextField(20);

        JLabel endDateLabel = new JLabel("End Date (yyyy-MM-dd):");
        endDateField = new JTextField(20);

        submitButton = new JButton("Submit");
        cancelButton = new JButton("Cancel");

        // Style buttons
        submitButton.setBackground(new Color(40, 167, 69));
        submitButton.setForeground(Color.WHITE);
        submitButton.setFont(new Font("Arial", Font.BOLD, 14));

        cancelButton.setBackground(new Color(220, 53, 69));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFont(new Font("Arial", Font.BOLD, 14));

        // Add components to the layout
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Add spacing between components
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        add(electionNameLabel, gbc);

        gbc.gridx = 1;
        add(electionNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(startDateLabel, gbc);

        gbc.gridx = 1;
        add(startDateField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(endDateLabel, gbc);

        gbc.gridx = 1;
        add(endDateField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        add(submitButton, gbc);

        gbc.gridy = 4;
        add(cancelButton, gbc);

        setLocationRelativeTo(null); // Center the window
        setVisible(true);
    }

    // Getters for input fields
    public String getElectionName() {
        return electionNameField.getText().trim();
    }

    public String getStartDate() {
        return startDateField.getText().trim();
    }

    public String getEndDate() {
        return endDateField.getText().trim();
    }

    // Add listeners for buttons
    public void addSubmitButtonListener(ActionListener listener) {
        submitButton.addActionListener(listener);
    }

    public void addCancelButtonListener(ActionListener listener) {
        cancelButton.addActionListener(listener);
    }
}