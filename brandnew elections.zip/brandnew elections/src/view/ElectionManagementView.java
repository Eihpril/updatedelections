package src.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class ElectionManagementView extends JFrame {
    private JButton createElectionButton;
    private JButton viewElectionsButton;
    private JButton editElectionButton;
    private JButton deleteElectionButton;
    private JButton toggleElectionStatusButton;

    public ElectionManagementView() {
        setTitle("Election Management");
        setSize(400, 300); // Compact size
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout()); // Use GridBagLayout for better alignment

        // Create buttons
        createElectionButton = new JButton("Create New Election");
        viewElectionsButton = new JButton("View All Elections");
        editElectionButton = new JButton("Edit Election");
        deleteElectionButton = new JButton("Delete Election");
        toggleElectionStatusButton = new JButton("Activate/Deactivate Election");

        // Style buttons
        Dimension buttonSize = new Dimension(200, 40);
        createElectionButton.setPreferredSize(buttonSize);
        viewElectionsButton.setPreferredSize(buttonSize);
        editElectionButton.setPreferredSize(buttonSize);
        deleteElectionButton.setPreferredSize(buttonSize);
        toggleElectionStatusButton.setPreferredSize(buttonSize);

        createElectionButton.setFont(new Font("Arial", Font.BOLD, 14));
        viewElectionsButton.setFont(new Font("Arial", Font.BOLD, 14));
        editElectionButton.setFont(new Font("Arial", Font.BOLD, 14));
        deleteElectionButton.setFont(new Font("Arial", Font.BOLD, 14));
        toggleElectionStatusButton.setFont(new Font("Arial", Font.BOLD, 14));

        createElectionButton.setBackground(new Color(0, 123, 255));
        createElectionButton.setForeground(Color.WHITE);
        viewElectionsButton.setBackground(new Color(40, 167, 69));
        viewElectionsButton.setForeground(Color.WHITE);
        editElectionButton.setBackground(new Color(255, 193, 7));
        editElectionButton.setForeground(Color.WHITE);
        deleteElectionButton.setBackground(new Color(220, 53, 69));
        deleteElectionButton.setForeground(Color.WHITE);
        toggleElectionStatusButton.setBackground(new Color(0, 123, 255));
        toggleElectionStatusButton.setForeground(Color.WHITE);

        // Add buttons to the layout
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 0, 10, 0); // Add spacing between buttons
        gbc.gridx = 0; // Center horizontally

        gbc.gridy = 0;
        add(createElectionButton, gbc);

        gbc.gridy = 1;
        add(viewElectionsButton, gbc);

        gbc.gridy = 2;
        add(editElectionButton, gbc);

        gbc.gridy = 3;
        add(deleteElectionButton, gbc);

        gbc.gridy = 4;
        add(toggleElectionStatusButton, gbc);

        setLocationRelativeTo(null); // Center the window
        setVisible(true);
    }

    // Add listeners for buttons
    public void addCreateElectionListener(ActionListener listener) {
        createElectionButton.addActionListener(listener);
    }

    public void addViewElectionsListener(ActionListener listener) {
        viewElectionsButton.addActionListener(listener);
    }

    public void addEditElectionListener(ActionListener listener) {
        editElectionButton.addActionListener(listener);
    }

    public void addDeleteElectionListener(ActionListener listener) {
        deleteElectionButton.addActionListener(listener);
    }

    // Add a listener for the Toggle Election Status button
    public void addToggleElectionStatusListener(ActionListener listener) {
        toggleElectionStatusButton.addActionListener(listener);
    }
}