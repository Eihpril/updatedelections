package src.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import src.model.Candidate;
import src.model.Database;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ManageCandidatesView extends JFrame {
    private JTable candidatesTable;
    private DefaultTableModel tableModel;

    private JTextField candidateNameField; // Declare candidateNameField

    public ManageCandidatesView() {
        setTitle("Manage Candidates");
        setSize(800, 600); // Adjusted size for better layout
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window
        setLayout(new BorderLayout());

        // Create a table to display candidates
        String[] columnNames = {"ID", "Name", "Party", "Age", "ID Number", "Phone Number", "Email", "Position", "County"};
        Object[][] data = {}; // Start with an empty table
        tableModel = new DefaultTableModel(data, columnNames);
        candidatesTable = new JTable(tableModel); // Initialize the JTable with the table model
        candidatesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); // Allow single row selection
        JScrollPane scrollPane = new JScrollPane(candidatesTable); // Add the table to a scroll pane

        // Add buttons for actions
        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add Candidate");
        JButton editButton = new JButton("Edit Candidate");
        JButton deleteButton = new JButton("Delete Candidate");
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);

        // Add components to the frame
        add(scrollPane, BorderLayout.CENTER); // Add the table to the center
        add(buttonPanel, BorderLayout.SOUTH); // Add the buttons to the bottom

        // Add functionality to buttons
        addButton.addActionListener(e -> addCandidate());
        editButton.addActionListener(e -> editCandidate());
        deleteButton.addActionListener(e -> deleteCandidate());

        // Load candidates from the database
        loadCandidates();

        setVisible(true);
    }

    private void loadCandidates() {
        Database db = new Database();
        List<Candidate> candidates = db.getAllCandidates();

        // Clear the table before loading new data
        tableModel.setRowCount(0);

        // Iterate through the list of candidates and add rows to the table
        for (Candidate candidate : candidates) {
            tableModel.addRow(new Object[]{
                candidate.getCandidateId(),
                candidate.getCandidateName(),
                candidate.getParty(),
                candidate.getAge(),
                candidate.getIdNumber(),
                candidate.getPhoneNumber(),
                candidate.getEmail(),
                candidate.getPosition(),
                candidate.getCounty()
            });
        }
    }

    private int getSelectedElectionId() {
        // Placeholder implementation: Replace with actual logic to get the selected election ID
        return 1; // Return a default election ID (replace with actual logic as needed)
    }

    private void addCandidate() {
        // Create input fields for candidate details
        JTextField nameField = new JTextField();
        JTextField partyField = new JTextField();
        JTextField ageField = new JTextField();
        JTextField idNumberField = new JTextField();
        JTextField phoneNumberField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField positionField = new JTextField();
        JTextField countyField = new JTextField();

        // Create a panel to hold the input fields
        Object[] fields = {
            "Name:", nameField,
            "Party:", partyField,
            "Age:", ageField,
            "ID Number:", idNumberField,
            "Phone Number:", phoneNumberField,
            "Email:", emailField,
            "Position:", positionField,
            "County:", countyField
        };

        // Show the input dialog
        int option = JOptionPane.showConfirmDialog(this, fields, "Add Candidate", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            // Get the input values
            String name = nameField.getText().trim();
            String party = partyField.getText().trim();
            String ageText = ageField.getText().trim();
            String idNumber = idNumberField.getText().trim();
            String phoneNumber = phoneNumberField.getText().trim();
            String email = emailField.getText().trim();
            String position = positionField.getText().trim();
            String county = countyField.getText().trim();

            // Validate inputs
            if (name.isEmpty() || party.isEmpty() || ageText.isEmpty() || idNumber.isEmpty() || phoneNumber.isEmpty() || position.isEmpty() || county.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields except email are required.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Validate age
            int age;
            try {
                age = Integer.parseInt(ageText);
                if (age < 18) {
                    JOptionPane.showMessageDialog(this, "Age must be 18 or older.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Age must be a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Create a Candidate object
            Candidate candidate = new Candidate(0, getSelectedElectionId(), name, party, 0, age, idNumber, phoneNumber, email, position, county);

            // Add the candidate to the database
            Database db = new Database();
            if (db.addCandidate(candidate)) {
                refreshCandidatesTable(); // Refresh the table to show the new candidate
                JOptionPane.showMessageDialog(this, "Candidate added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add candidate to the database.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void refreshCandidatesTable() {
        Database db = new Database(); // Create an instance of the Database class
        List<Candidate> candidates = db.getAllCandidates(); // Fetch all candidates from the database

        // Clear the table before loading new data
        tableModel.setRowCount(0);

        // Iterate through the list of candidates and add rows to the table
        for (Candidate candidate : candidates) {
            tableModel.addRow(new Object[]{
                candidate.getCandidateId(),
                candidate.getCandidateName(),
                candidate.getParty(),
                candidate.getAge(),
                candidate.getIdNumber(),
                candidate.getPhoneNumber(),
                candidate.getEmail(),
                candidate.getPosition(),
                candidate.getCounty()
            });
        }
    }

    private void editCandidate() {
        int selectedRow = candidatesTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a candidate to edit.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Get current values from the selected row
        int candidateId = (int) tableModel.getValueAt(selectedRow, 0);
        String currentName = (String) tableModel.getValueAt(selectedRow, 1);
        String currentParty = (String) tableModel.getValueAt(selectedRow, 2);
        String currentAge = String.valueOf(tableModel.getValueAt(selectedRow, 3));
        String currentIdNumber = (String) tableModel.getValueAt(selectedRow, 4);
        String currentPhoneNumber = (String) tableModel.getValueAt(selectedRow, 5);
        String currentEmail = (String) tableModel.getValueAt(selectedRow, 6);
        String currentPosition = (String) tableModel.getValueAt(selectedRow, 7);
        String currentCounty = (String) tableModel.getValueAt(selectedRow, 8);

        // Create input fields pre-filled with current values
        JTextField nameField = new JTextField(currentName);
        JTextField partyField = new JTextField(currentParty);
        JTextField ageField = new JTextField(currentAge);
        JTextField idNumberField = new JTextField(currentIdNumber);
        JTextField phoneNumberField = new JTextField(currentPhoneNumber);
        JTextField emailField = new JTextField(currentEmail);
        JTextField positionField = new JTextField(currentPosition);
        JTextField countyField = new JTextField(currentCounty);

        Object[] fields = {
            "Name:", nameField,
            "Party:", partyField,
            "Age:", ageField,
            "ID Number:", idNumberField,
            "Phone Number:", phoneNumberField,
            "Email:", emailField,
            "Position:", positionField,
            "County:", countyField
        };

        int option = JOptionPane.showConfirmDialog(this, fields, "Edit Candidate", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String name = nameField.getText().trim();
            String party = partyField.getText().trim();
            String ageText = ageField.getText().trim();
            String idNumber = idNumberField.getText().trim();
            String phoneNumber = phoneNumberField.getText().trim();
            String email = emailField.getText().trim();
            String position = positionField.getText().trim();
            String county = countyField.getText().trim();

            // Validate inputs
            if (name.isEmpty() || party.isEmpty() || ageText.isEmpty() || idNumber.isEmpty() || phoneNumber.isEmpty() || position.isEmpty() || county.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields except email are required.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Validate age
            int age;
            try {
                age = Integer.parseInt(ageText);
                if (age < 18) {
                    JOptionPane.showMessageDialog(this, "Age must be 18 or older.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Age must be a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Create a Candidate object
            Candidate candidate = new Candidate(candidateId, 1, name, party, 0, age, idNumber, phoneNumber, email, position, county);

            // Update the database
            Database db = new Database();
            if (db.updateCandidate(candidate)) {
                loadCandidates(); // Reload the table after editing
                JOptionPane.showMessageDialog(this, "Candidate updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update candidate in the database.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void deleteCandidate() {
        int selectedRow = candidatesTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a candidate to delete.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Get the candidate ID from the selected row
        int candidateId = (int) tableModel.getValueAt(selectedRow, 0);

        // Confirm deletion
        int option = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this candidate?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
            // Delete from the database
            Database db = new Database();
            if (db.deleteCandidate(candidateId)) {
                loadCandidates(); // Reload the table after deletion
                JOptionPane.showMessageDialog(this, "Candidate deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete candidate from the database.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        new ManageCandidatesView(); // Launch the application
    }
}