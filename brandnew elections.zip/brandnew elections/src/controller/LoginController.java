package src.controller;

import src.model.Database;
import src.view.LoginView;
import src.view.RegisterView;
import src.view.ResultsView;

import javax.swing.*;

public class LoginController {
    private LoginView loginView;
    private Database database;
    private Admincontroller adminController;
    private VoterController voterController;

    /**
     * Constructor for LoginController.
     * Initializes the controller and sets up action listeners for the LoginView.
     *
     * @param loginView The LoginView instance.
     */
    public LoginController(LoginView loginView) {
        this.loginView = loginView;
        this.database = new Database();

        // Initialize AdminController and VoterController
        this.adminController = new Admincontroller(database);
        this.voterController = new VoterController(loginView, database);

        // Add action listener to the login button
        this.loginView.addLoginButtonListener(e -> handleLogin());

        // Add action listener to the register button
        this.loginView.addRegisterButtonListener(e -> openRegisterView());

        // Add action listener to the view results button
        this.loginView.addViewResultsButtonListener(e -> handleViewResults());
    }

    /**
     * Handles the login process for both voters and admins.
     */
    private void handleLogin() {
        String role = loginView.getSelectedRole(); // Get the selected role
        String nationalId = loginView.getNationalId();
        String username = loginView.getUsername();
        String password = loginView.getPassword();

        // Validate inputs
        if (username == null || username.trim().isEmpty()) {
            JOptionPane.showMessageDialog(loginView, "Please enter your username.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (password == null || password.trim().isEmpty()) {
            JOptionPane.showMessageDialog(loginView, "Please enter your password.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Handle login based on role
        if ("Voter".equals(role)) {
            // Validate National ID for voters
            if (nationalId == null || nationalId.trim().isEmpty()) {
                JOptionPane.showMessageDialog(loginView, "Please enter your National ID.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Authenticate voter
            boolean isAuthenticated = voterController.authenticateVoter(nationalId, username, password);

            if (isAuthenticated) {
                System.out.println("✅ Voter login successful.");
                loginView.dispose(); // Close the login view
                voterController.openVotingView(); // Proceed to voting view
            } else {
                JOptionPane.showMessageDialog(loginView, "Invalid National ID, username, or password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
            }
        } else if ("Admin".equals(role)) {
            // Authenticate admin
            boolean isAuthenticated = adminController.authenticateAdmin(username, password);

            if (isAuthenticated) {
                System.out.println("✅ Admin login successful.");
                loginView.dispose(); // Close the login view
                adminController.openAdminDashboard(); // Proceed to admin dashboard
            } else {
                JOptionPane.showMessageDialog(loginView, "Invalid admin username or password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(loginView, "Please select a valid role.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Redirects the user to the registration page.
     */
    private void openRegisterView() {
        System.out.println("Redirecting to Register View...");
        RegisterView registerView = new RegisterView();
        new RegisterController(registerView, database);
    }

    /**
     * Fetches and displays up-to-date election results.
     */
    private void handleViewResults() {
        System.out.println("Fetching up-to-date election results...");
        Object[][] results = database.getElectionResults(); // Fetch results from the database
        if (results != null && results.length > 0) {
            new ResultsView(results); // Display results in the ResultsView
        } else {
            JOptionPane.showMessageDialog(loginView, "No results available at the moment.", "Info", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}