package src.controller;

import src.model.Database;
import src.view.ElectionManagementView;
import src.view.NewElectionsForm;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

public class ElectionManagementController {
    private ElectionManagementView electionManagementView;
    private Database database;

    public ElectionManagementController(ElectionManagementView electionManagementView, Database database) {
        this.electionManagementView = electionManagementView;
        this.database = database;

        // Add listeners to the buttons
        this.electionManagementView.addCreateElectionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createElection();
            }
        });

        this.electionManagementView.addViewElectionsListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewElections();
            }
        });

        this.electionManagementView.addEditElectionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editElection();
            }
        });

        this.electionManagementView.addDeleteElectionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteElection();
            }
        });

        this.electionManagementView.addToggleElectionStatusListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                toggleElectionStatus();
            }
        });
    }

    private void createElection() {
    NewElectionsForm newElectionsForm = new NewElectionsForm();

    // Add listener for the Submit button
    newElectionsForm.addSubmitButtonListener(e -> {
        String electionName = newElectionsForm.getElectionName();
        String startDateStr = newElectionsForm.getStartDate();
        String endDateStr = newElectionsForm.getEndDate();

        if (electionName.isEmpty() || startDateStr.isEmpty() || endDateStr.isEmpty()) {
            JOptionPane.showMessageDialog(newElectionsForm, "All fields are required.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd");
            java.util.Date startDate = dateFormat.parse(startDateStr);
            java.util.Date endDate = dateFormat.parse(endDateStr);

            if (database.createElection(electionName, new java.sql.Date(startDate.getTime()), new java.sql.Date(endDate.getTime()))) {
                JOptionPane.showMessageDialog(newElectionsForm, "Election created successfully!");
                newElectionsForm.dispose(); // Close the form
            } else {
                JOptionPane.showMessageDialog(newElectionsForm, "Failed to create election.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(newElectionsForm, "Invalid date format. Please use yyyy-MM-dd.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    });

    // Add listener for the Cancel button
    newElectionsForm.addCancelButtonListener(e -> newElectionsForm.dispose());
}

private void viewElections() {
    String elections = database.getAllElections(); // Fetch elections from the database
    if (elections.isEmpty()) {
        JOptionPane.showMessageDialog(electionManagementView, "No elections found.", "All Elections", JOptionPane.INFORMATION_MESSAGE);
    } else {
        JOptionPane.showMessageDialog(electionManagementView, elections, "All Elections", JOptionPane.INFORMATION_MESSAGE);
    }
}

private void editElection() {
    String electionId = JOptionPane.showInputDialog("Enter Election ID to Edit:");
    if (electionId != null && !electionId.trim().isEmpty()) {
        String newName = JOptionPane.showInputDialog("Enter New Election Name:");
        if (newName != null && !newName.trim().isEmpty()) {
            String startDateStr = JOptionPane.showInputDialog("Enter Start Date (yyyy-MM-dd):");
            String endDateStr = JOptionPane.showInputDialog("Enter End Date (yyyy-MM-dd):");

            try {
                java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd");

                // Parse the start date
                java.util.Date startDate = null;
                if (startDateStr != null && !startDateStr.trim().isEmpty()) {
                    startDate = dateFormat.parse(startDateStr);
                } else {
                    JOptionPane.showMessageDialog(electionManagementView, "Start date is required.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Parse the end date
                java.util.Date endDate = null;
                if (endDateStr != null && !endDateStr.trim().isEmpty()) {
                    endDate = dateFormat.parse(endDateStr);
                } else {
                    JOptionPane.showMessageDialog(electionManagementView, "End date is required.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Update the election in the database
                if (database.updateElection(
                        Integer.parseInt(electionId),
                        newName,
                        new java.sql.Date(startDate.getTime()),
                        new java.sql.Date(endDate.getTime())
                )) {
                    JOptionPane.showMessageDialog(electionManagementView, "Election updated successfully!");
                } else {
                    JOptionPane.showMessageDialog(electionManagementView, "Failed to update election.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(electionManagementView, "Invalid date format. Please use yyyy-MM-dd.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(electionManagementView, "Election name is required.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(electionManagementView, "Election ID is required.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}

    private void deleteElection() {
        String electionId = JOptionPane.showInputDialog("Enter Election ID to Delete:");
        if (electionId != null && !electionId.trim().isEmpty()) {
            if (database.deleteElection(Integer.parseInt(electionId))) {
                JOptionPane.showMessageDialog(electionManagementView, "Election deleted successfully!");
            } else {
                JOptionPane.showMessageDialog(electionManagementView, "Failed to delete election.");
            }
        }
    }
        private void toggleElectionStatus() {
        String electionId = JOptionPane.showInputDialog("Enter Election ID to Activate/Deactivate:");
        if (electionId != null && !electionId.trim().isEmpty()) {
            // Fetch the current status of the election
            Object[] activeElection = database.getActiveElection();
            boolean isActive = activeElection != null && (int) activeElection[0] == Integer.parseInt(electionId);
    
            // Toggle the status
            if (database.setElectionActiveStatus(Integer.parseInt(electionId), !isActive)) {
                String status = isActive ? "deactivated" : "activated";
                JOptionPane.showMessageDialog(electionManagementView, "Election successfully " + status + "!");
            } else {
                JOptionPane.showMessageDialog(electionManagementView, "Failed to update election status.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(electionManagementView, "Election ID is required.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
}