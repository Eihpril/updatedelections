package src.controller;

import src.model.Database;
import src.view.Admindashboard;

public class Admincontroller {
    private Database database;

    public Admincontroller(Database database) {
        this.database = database;
    }

    public boolean authenticateAdmin(String username, String password) {
        return database.authenticateAdmin(username, password);
    }

    public void openAdminDashboard() {
        Admindashboard adminDashboardView = new Admindashboard();
        // Add logic to initialize the admin dashboard
    }
}