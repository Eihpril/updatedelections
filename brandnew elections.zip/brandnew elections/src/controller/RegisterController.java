package src.controller;

import src.model.Database;
import src.view.RegisterView;

public class RegisterController {
    private RegisterView registerView;
    private Database database;

    public RegisterController(RegisterView registerView, Database database) {
        this.registerView = registerView;
        this.database = database;

        // Attach listener to the submit button
        this.registerView.addSubmitButtonListener(e -> handleRegistration());
    }

    private void handleRegistration() {
        System.out.println("DEBUG: handleRegistration called!"); // Debug statement

        // Get user input
        String nationalId = registerView.getNationalId();
        String firstName = registerView.getFirstName();
        String lastName = registerView.getLastName();
        String username = registerView.getUsername();
        String password = registerView.getPassword();

        // Debug input values
        System.out.println("DEBUG: National ID: " + nationalId);
        System.out.println("DEBUG: First Name: " + firstName);
        System.out.println("DEBUG: Last Name: " + lastName);
        System.out.println("DEBUG: Username: " + username);
        System.out.println("DEBUG: Password: " + password);

        // Validate inputs
        if (nationalId.isEmpty() || firstName.isEmpty() || lastName.isEmpty() || username.isEmpty() || password.isEmpty()) {
            registerView.showMessage("All fields are required.");
            return;
        }

        // Check if the citizen exists and details match
        if (!database.verifyCitizenDetails(nationalId, firstName, lastName)) {
            registerView.showMessage("Citizen details do not match our records.");
            return;
        }

        // Check if the citizen is already registered
        if (database.isCitizenAlreadyRegistered(nationalId)) {
            registerView.showMessage("This citizen is already registered to vote.");
            return;
        }

        // Register the voter
        if (database.registerVoter(nationalId, username, password)) {
            registerView.showMessage("Registration successful!");
        } else {
            registerView.showMessage("Registration failed. Please try again.");
        }
    }
}