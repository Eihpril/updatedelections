package src.controller;

import java.util.List;

import src.model.Database;
import src.view.LoginView;
import src.view.VotingView;

public class VoterController {
    private LoginView loginView;
    private Database database;
    private int voterId;

    public VoterController(LoginView loginView, Database database) {
        this.loginView = loginView;
        this.database = database;
    }

    public void handleVoterLogin() {
        String username = loginView.getUsername();
        String password = loginView.getPassword();

        // Validate inputs
        if (username == null || username.trim().isEmpty()) {
            loginView.showMessage("Please enter your username.");
            return;
        }

        if (password == null || password.trim().isEmpty()) {
            loginView.showMessage("Please enter your password.");
            return;
        }

        // Authenticate voter
        if (database.authenticateVoter(username, password)) {
            loginView.showMessage("Voter login successful!");
            openVoterDashboard();
            this.voterId = Integer.parseInt(loginView.getVoterId()); // Retrieve voter ID from loginView and store it
        } else {
            loginView.showMessage("Invalid voter username or password.");
        }
    }

    public int getVoterId() {
        return voterId; // Return the stored voter ID
    }

    private void openVoterDashboard() {
        System.out.println("Redirecting to Voting View...");
        VotingView votingView = new VotingView(null);
        new VotingController(votingView, database, voterId); // Connect VotingController
    }

    public boolean authenticateVoter(String nationalId, String username, String password) {
        voterId = database.authenticateVoterByNationalId(nationalId, username, password);
        return voterId > 0;
    }

    public void openVotingView() {
        System.out.println("Redirecting to Voting View...");
        List<Object[]> candidates = database.getAllCandidatesForVoting(); // Fetch candidates for voting
        VotingView votingView = new VotingView(candidates);
        new VotingController(votingView, database, voterId); // No need to pass electionId
    }
}