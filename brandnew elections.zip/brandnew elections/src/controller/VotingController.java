package src.controller;

import src.model.Database;
import src.view.ResultsView;
import src.view.VotingView;

import javax.swing.*;

public class VotingController {
    private VotingView votingView;
    private Database database;
    private int voterId;

    public VotingController(VotingView votingView, Database database, int voterId) {
        this.votingView = votingView;
        this.database = database;
        this.voterId = voterId;

        // Add action listeners to the VotingView
        this.votingView.addVoteButtonListener(e -> handleVote());
        this.votingView.addViewResultsButtonListener(e -> handleViewResults());
    }

    /**
     * Handles the voting process.
     */
    private void handleVote() {
        String selectedCandidate = votingView.getSelectedCandidate();
        if (selectedCandidate != null) {
            boolean success = database.recordVote(voterId, selectedCandidate);
            if (success) {
                JOptionPane.showMessageDialog(votingView, "Vote cast successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(votingView, "Failed to cast vote. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(votingView, "Please select a candidate.", "Error", JOptionPane.WARNING_MESSAGE);
        }
    }

    /**
     * Handles the process of viewing results.
     */
    private void handleViewResults() {
        System.out.println("Redirecting to Results View...");
        Object[][] results = database.getElectionResults(); // Fetch results from the database
        if (results != null && results.length > 0) {
            new ResultsView(results); // Display results in the ResultsView
        } else {
            JOptionPane.showMessageDialog(votingView, "No results available at the moment.", "Info", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}