package src.controller;

import src.model.Database;
import src.view.ResultsView;

public class ResultsController {
    private Database database;
    private ResultsView resultsView;

    public ResultsController() {
        this.database = new Database();
        this.resultsView = new ResultsView(fetchResults());

        // Attach refresh button listener
        resultsView.addRefreshButtonListener(e -> refreshResults());
    }

    private Object[][] fetchResults() {
        // Fetch results from the database
        Object[][] results = database.getElectionResults();
        if (results.length == 0) {
            System.out.println("No results available."); // Debug statement
        }
        return results;
    }

    private void refreshResults() {
        System.out.println("ResultsController: Refreshing results..."); // Debug statement
        Object[][] results = fetchResults();
        resultsView.setResults(results);
    }
}