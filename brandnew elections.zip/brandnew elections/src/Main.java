package src;

import src.controller.LoginController;
import src.model.Database;
import src.view.LoginView;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                // Establish database connection
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/brandnew_system", "root", "Mawira@10926");
                Database database = new Database();

                // Initialize the LoginView and LoginController
                LoginView loginView = new LoginView();
                new LoginController(loginView);

                System.out.println("DEBUG: LoginView initialized and connected to LoginController.");
            } catch (Exception e) {
                System.err.println("ERROR: Failed to initialize the application.");
                e.printStackTrace();
            }
        });
    }
}